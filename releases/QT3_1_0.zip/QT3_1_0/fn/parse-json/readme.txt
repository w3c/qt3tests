The data files in this directory are taken from http://json.org/example.html

The original carries no copyright or licensing information.

Captured on 2011-04-01 by Michael Kay, Saxonica